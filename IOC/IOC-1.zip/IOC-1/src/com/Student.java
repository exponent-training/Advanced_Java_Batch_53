package com;

public class Student {

	Student() {
		System.out.println("Object Created");
	}

}
