package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Factory {

	public static void main(String[] args) {

//		ClassPathResource resource = new ClassPathResource("beans.xml");

//		BeanFactory bf = new XmlBeanFactory(resource);

//		Student stu = bf.getBean("st", Student.class);

		System.out.println("------------------------------------------------------");

//		ApplicationContext - J2EE Container.

		ApplicationContext apc = new ClassPathXmlApplicationContext("beans.xml");
//		Student stu1 = apc.getBean("st", Student.class);

//		what is Container ? 
//		What is beans.xml?
//		Diff beatween Core Conatiner and J2ee Container(applicationContext).
//		what is bean Tag ?

	}
}
