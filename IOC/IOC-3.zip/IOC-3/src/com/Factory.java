package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Factory {

	public static void main(String[] args) {

		ApplicationContext apc = new ClassPathXmlApplicationContext("beans.xml");
		Student stu1 = apc.getBean("st", Student.class);
		System.out.println(stu1);
		/*
		 * System.out.println(stu1.getSchool().hashCode());
		 * 
		 * System.out.println("-----------------------------------------------------");
		 * Student stu2 = apc.getBean("st", Student.class);
		 * System.out.println(stu2.hashCode());
		 * System.out.println(stu2.getSchool().hashCode());
		 */

	}
}
