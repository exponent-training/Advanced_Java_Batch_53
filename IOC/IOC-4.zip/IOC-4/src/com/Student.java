package com;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Student implements DisposableBean , InitializingBean{

	private int sid;

	private String sname;

	private List<Integer> number = new ArrayList<Integer>();

	private Set<Integer> pincodes = new HashSet<Integer>();

	private Map<String, Integer> subjectCodes = new HashMap<String, Integer>();

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public List<Integer> getNumber() {
		return number;
	}

	public void setNumber(List<Integer> number) {
		this.number = number;
	}

	public Set<Integer> getPincodes() {
		return pincodes;
	}

	public void setPincodes(Set<Integer> pincodes) {
		this.pincodes = pincodes;
	}

	public Map<String, Integer> getSubjectCodes() {
		return subjectCodes;
	}

	public void setSubjectCodes(Map<String, Integer> subjectCodes) {
		this.subjectCodes = subjectCodes;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", number=" + number + ", pincodes=" + pincodes
				+ ", subjectCodes=" + subjectCodes + "]";
	}

	@Override
	public void afterPropertiesSet() throws Exception {

		System.out.println("Init method call");
		
	}

	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		
	}

}
