package com.Configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

import com.Entity.Department;
import com.Entity.Employee;

//@component..
@Configuration
public class AppConfig {

	@Bean(name = "dept1")
	@Primary
	public Department credateDept() {
		Department dept = new Department();
		dept.setDid(102);
		dept.setDeptName("DEV");

		return dept;
	}
	
	@Bean(name = "dept2")
	@Primary
	public Department credateDept1() {
		Department dept1 = new Department();
		dept1.setDid(103);
		dept1.setDeptName("QA");

		return dept1;
	}
	
	@Bean(name = "dept3")
	public Department credateDept2() {
		Department dept2 = new Department();
		dept2.setDid(104);
		dept2.setDeptName("PROD");

		return dept2;
	}
	
	
	
	

	@Bean(name = "emp1")
	@Scope(value = "prototype")
	public Employee createEmp() {
		Employee emp = new Employee();
		emp.setEid(101);
		emp.setEname("raj");
		emp.setEaddress("Pune");
//		emp.setDept(credateDept());

		return emp;
	}

	@Bean(name = "emp2")
	public Employee createEmp1() {
		Employee emp1 = new Employee();
		emp1.setEid(102);
		emp1.setEname("karan");
		emp1.setEaddress("mumbai");

		return emp1;
	}

}
