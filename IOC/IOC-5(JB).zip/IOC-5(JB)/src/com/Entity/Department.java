package com.Entity;

public class Department {

	private int did;

	private String deptName;

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	@Override
	public String toString() {
		return "Department [did=" + did + ", deptName=" + deptName + "]";
	}

}
