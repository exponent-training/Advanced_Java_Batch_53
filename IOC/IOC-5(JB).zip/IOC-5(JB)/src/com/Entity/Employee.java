package com.Entity;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {

	private int eid;

	private String ename;

	private String eaddress;

	@Autowired
//	@Qualifier(value = "DEPT")
	private Department dept;

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEaddress() {
		return eaddress;
	}

	public void setEaddress(String eaddress) {
		this.eaddress = eaddress;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", eaddress=" + eaddress + ", dept=" + dept + "]";
	}

	@PostConstruct
	public void init() {
		System.out.println("Custome Init method");
	}

	@PreDestroy
	public void destroy() {
		System.out.println("Custome Destroy method");
	}

}
