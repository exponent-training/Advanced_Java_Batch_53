package com.Controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.Configuration.AppConfig;
import com.Entity.Employee;

public class HomeController {

	public static void main(String[] args) {

		ApplicationContext apc = new AnnotationConfigApplicationContext(AppConfig.class);
		Employee emp = apc.getBean("emp1", Employee.class);
		System.out.println(emp);
		/*
		 * Employee emp1 = apc.getBean("emp1", Employee.class);
		 * System.out.println(emp1.hashCode());
		 */

	}
}
