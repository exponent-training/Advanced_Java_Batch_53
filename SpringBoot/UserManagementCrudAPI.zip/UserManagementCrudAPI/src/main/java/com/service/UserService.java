package com.service;

import java.util.List;

import com.entity.User;

public interface UserService {
	
	public int registerUser(User user);

	public List<User> getDetailsOfAllUsers();

	public User getUserById(int id);

	public int updateUser(User user);

}
