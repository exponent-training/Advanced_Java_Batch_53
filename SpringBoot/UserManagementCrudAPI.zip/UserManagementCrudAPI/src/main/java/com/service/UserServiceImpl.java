package com.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.User;
import com.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	UserRepository repository;

	@Override
	public int registerUser(User user) {

		if (user != null) {
			repository.save(user);
			logger.info("user added: " + user);
			return 1;
		} else {
			logger.info("User is null");
			return 0;
		}

	}

	@Override
	public List<User> getDetailsOfAllUsers() {
		List<User> userList = repository.findAll();
		
		if (!userList.isEmpty()) {
			logger.info("UserList: "+userList);
			return userList;
		} else {
			return null;
		}
		
	}

	@Override
	public User getUserById(int id) {
		 Optional<User> userOptional =repository.findById(id);
		 if (userOptional.isPresent()) {
			User user=userOptional.get();
			logger.info("User: "+user);
			return user;
		} else {
			logger.info("User is not present");
			return null;
		}
	
	}

	@Override
	public int updateUser(User user) {
		if (user!= null) {
			repository.save(user);
			return 1;
		} else {
			return 0;
		}
		
	}

}
