package com.Repositories;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Entity.Student;

@Repository
public interface StudentRepo extends JpaRepository<Student, Integer> {

	public List<Student> findBySname(String name);

	public List<Student> findBySnameAndMarks(String name, double marks);

	public List<Student> findBySnameLike(String value);

	@Query(value = "select * from student", nativeQuery = true)
	public List<Student> getAllStudent();
	
	@Transactional
	@Query(value = "delete from student where sid = :id" , nativeQuery = true)
	@Modifying
	public void deleteStudent( int id);
	
//	@Procedure(name = "getCall()")
//	public void callStireProcedure(@Param);

}
