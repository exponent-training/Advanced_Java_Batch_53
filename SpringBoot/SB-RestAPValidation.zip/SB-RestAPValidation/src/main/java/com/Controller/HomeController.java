package com.Controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.Entity.Credentials;
import com.Entity.Student;
import com.Repositories.StudentRepo;

//User managment

@RestController
@Cacheable
public class HomeController {
	
	@Autowired
	private StudentRepo sr;

	Logger logger = LoggerFactory.getLogger(HomeController.class);

	@PostMapping(value = "/postData")
	public ResponseEntity<?> firstRestApi(@Valid @RequestBody Student student) {
		logger.info("this is firs API GET Call");

		System.out.println(student);

		return new ResponseEntity(student, HttpStatus.OK);

	}

	@GetMapping(value = "/getData/{id}")
	@Cacheable(cacheNames = "1IdData")
	@CacheEvict(cacheNames = "1IdData")
	public ResponseEntity<?> getStudentByID(@PathVariable("id") int i) {
		logger.info("this is firs API GET Call");

		Student st = sr.findById(i).get();

		return new ResponseEntity(st, HttpStatus.OK);

	}

}
