package com.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.validation.annotation.Validated;


import lombok.Data;

@Entity
@Data
@Validated
@Cacheable
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int sid;

	@NotNull(message = "this filed can not be null")
	@NotBlank(message = "this filed can not be Blank")
	private String sname;

	
	private double marks;

	@Size(max = 20,message = "Address length should be less than 20")
	private String saddress;

	@Min(value = 18,message = "age should be greater than 18")
//	@Pattern(regexp = "[0-9]")
	private int age;

}
