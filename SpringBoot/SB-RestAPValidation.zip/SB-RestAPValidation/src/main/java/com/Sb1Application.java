package com;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import com.Entity.Student;
import com.Repositories.StudentRepo;

@SpringBootApplication
//@EnableAutoConfiguration
@EnableCaching
public class Sb1Application {

//	static Logger logger = LoggerFactory.getLogger(Sb1Application.class);

	public static void main(String[] args) {
//		System.out.println("this is main method");
		SpringApplication.run(Sb1Application.class, args);

	}

}
