package com;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Endpoint(id = "batch53ep")
public class CustomeEndpoints {

	@ReadOperation
	@RequestMapping(method = RequestMethod.GET)
	public String getEndpoint() {
		return "application is runnung fine!! Dont worry.";
	}

}
