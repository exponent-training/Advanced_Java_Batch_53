package com.Model;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class Employee {

	private int eid;

	private String ename;

	private String eaddress;

	private double esalary;

	private String gender;

	private String country;

	private int number;

	private LocalDate dateofbirth;

	private int age;

}
