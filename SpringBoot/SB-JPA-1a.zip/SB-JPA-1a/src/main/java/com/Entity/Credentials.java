package com.Entity;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlRootElement
public class Credentials {

	private String username;

	private String password;

}
