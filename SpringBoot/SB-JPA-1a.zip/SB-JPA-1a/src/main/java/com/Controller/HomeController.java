package com.Controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.Entity.Credentials;

//User managment

@RestController
public class HomeController {

	Logger logger = LoggerFactory.getLogger(HomeController.class);

	@GetMapping(value = "/get", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_XML_VALUE)
	@ResponseStatus(code = HttpStatus.OK, reason = "get call success")
	public ResponseEntity<?> firstRestApi() {
		logger.info("this is firs API GET Call");

		return new ResponseEntity("Welcome to First API", HttpStatus.OK);

	}

	@PostMapping(value = "/post", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> secondAPI(@RequestBody Credentials cred) {
		logger.info("this is Second API POST Call");

		System.out.println(cred);

		return new ResponseEntity(cred, HttpStatus.OK);
	}

	@PostMapping("/post/singleparam")
	public String ThirdAPI(@RequestParam("username") String un, @RequestParam("password") String ps) {
		logger.info("this is Third API POST Call");

		System.out.println(un + " " + ps);

		return un + " " + ps;
	}

	@PostMapping("/post/singleparam/{username}/{password}")
	public String fourthAPI(@PathVariable("username") String un, @PathVariable("password") String ps) {
		logger.info("this is fourthAPI  POST Call");

		System.out.println(un + " " + ps);

		return un + " " + ps;
	}

}
