package com;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.Entity.Student;
import com.Repositories.StudentRepo;

@SpringBootApplication
//@EnableAutoConfiguration
public class Sb1Application {

//	static Logger logger = LoggerFactory.getLogger(Sb1Application.class);

	public static void main(String[] args) {
//		System.out.println("this is main method");
		ConfigurableApplicationContext run = SpringApplication.run(Sb1Application.class, args);
		StudentRepo sr = run.getBean(StudentRepo.class);

		Student st1 = new Student();
		st1.setSname("Raj");
		st1.setMarks(95.0);

		Student st2 = new Student();
		st2.setSname("ravi");
		st2.setMarks(95.0);

		Student st3 = new Student();
		st3.setSname("karan");
		st3.setMarks(95.0);

		List<Student> ls = Arrays.asList(st1, st2, st3);
//      2 -> persist.
//		upsert = update + insert.
//		sr.save(st);
//		sr.saveAll(ls);

//		3 -> get operation.
//		Iterable<Student> as = sr.findAll();
//		System.out.println(as);
//		Optional<Student> student = sr.findById(5);
//		if (student.isPresent()) {
//			System.out.println(student.get());
//		}
//		List<Integer> lid = Arrays.asList(3, 4, 5);
//
//		Iterable<Student> allidsData = sr.findAllById(lid);
//		System.out.println(allidsData);

//		5 ->  delete.
//		sr.delete(student.get());
//		sr.deleteById(4);
//		sr.deleteAll();
//		this methods deleted all student 
//		sr.deleteAll();
//		this method takes list of entites for delete.
//		sr.deleteAllById(Arrays.asList(2, 3));
//		this methods takes list of ids for delete

//		1 -> count operation.
//		long count = sr.count();
//		System.out.println(count);

//		1 -> ID Exist Or not just check.
//		boolean result = sr.existsById(5);
//		if (result) {
//			System.out.println("ID Present ");
//		}

	}

}
