package com.Controller;

import javax.websocket.server.PathParam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Entity.Credentials;

@RestController
public class HomeController {

	Logger logger = LoggerFactory.getLogger(HomeController.class);

	@GetMapping("/get")
	public String firstRestApi() {
		logger.info("this is firs API GET Call");

		return "Welcome to First API";
	}

	@PostMapping("/post")
	public Credentials secondAPI(@RequestBody Credentials cred) {
		logger.info("this is Second API POST Call");

		System.out.println(cred);

		return cred;
	}

	@PostMapping("/post/singleparam")
	public String ThirdAPI(@RequestParam("username") String un, @RequestParam("password") String ps) {
		logger.info("this is Third API POST Call");

		System.out.println(un + " " + ps);

		return un + " " + ps;
	}

	@PostMapping("/post/singleparam/{username}/{password}")
	public String fourthAPI(@PathVariable("username") String un, @PathVariable("password") String ps) {
		logger.info("this is fourthAPI  POST Call");

		System.out.println(un + " " + ps);

		return un + " " + ps;
	}

}
