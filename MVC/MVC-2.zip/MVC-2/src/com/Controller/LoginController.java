package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

	@RequestMapping(value = "/log")
	public void getLogCall(@RequestParam("un") String username, @RequestParam("ps") String password) {

		System.out.println("Username :- " + username);
		System.out.println("Password :- " + password);
		System.out.println("Log request called in backend");
	}
}
