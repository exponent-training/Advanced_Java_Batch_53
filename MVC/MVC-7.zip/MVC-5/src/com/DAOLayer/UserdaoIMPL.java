package com.DAOLayer;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Model.User;

@Repository
public class UserdaoIMPL implements Userdao {

	@Autowired
	private SessionFactory sf;

	@Override
	public void addUserInDao(User user) {

		System.out.println("I am in Dao Layer");
		System.out.println(user);
		System.out.println("------------------------");

		Session s = sf.openSession();
		s.save(user);
		s.beginTransaction().commit();
		System.out.println("User added");

	}

	@Override
	public List<User> loginUserInDao() {

		System.out.println(" Iam in DAO layer :: Log()");

		Session s = sf.openSession();
		Query query = s.createQuery("from User");
		List<User> ulist = query.getResultList();

		return ulist;

	}

	@Override
	public List<User> deleteUserInDAO(int id) {

		System.out.println("I am in DAO Layer");

		Session s = sf.openSession();
		User user = s.get(User.class, id);
		if (user != null) {
			s.delete(user);
			s.beginTransaction().commit();
			System.out.println("User Deleted");
		} else {
			System.out.println("Id invalid");
		}

		Query query = s.createQuery("from User");
		List<User> ulist = query.getResultList();

		return ulist;

	}

	@Override
	public User getSingleUserByIDinDAO(int id) {

		Session s = sf.openSession();
		User user = s.get(User.class, id);

		return user;
	}

	
	@Override
	public List<User> updateUserInDao(User user) {
		
		Session s = sf.openSession();
		s.update(user);
		s.beginTransaction().commit();
		System.out.println("User Updated");
		
		Query query = s.createQuery("from User");
		List<User> ulist = query.getResultList();

		return ulist;
		
	}
}
