package com.repository;



import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.entity.User;

@Repository
public class UserDaoImpl implements UserDao{
	
	@Autowired
	private SessionFactory sf;

	@Override
	public void registerUser(User user) {
	System.out.println("register user in dao layer");
	
	Session session = sf.openSession();
	session.save(user);
	session.beginTransaction().commit();
		System.out.println("user saved successfully!!");
	}

	@Override
	public List<User> getAllDetails() {
		System.out.println("details user in dao layer");
		Session session = sf.openSession();
		
		Query query = session.createQuery("from User");
		List<User> userList =query.getResultList();
		return userList;
	}

}
