package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.User;
import com.repository.UserDao;

@Service
public class UserServiImpl implements UserService {

	@Autowired
	UserDao dao;

	public static final String username = "admin";

	public static final String password = "admin@1234";

	@Override
	public int registerUser(User user) {
		System.out.println("regiser user Service layer");

		System.out.println(user);

		if (user != null) {
			dao.registerUser(user);
			return 0;
		} else {
			return 1;
		}

	}

	@Override
	public List<User> getAllDetails(String uname, String pswd) {
		
		if (uname.equals(username) && pswd.equals(password)) {
			
			List<User> userList = dao.getAllDetails();
			return userList;
		} else {
			return null;
		}
		
	}

}
