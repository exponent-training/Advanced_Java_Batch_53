package com;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.entity.User;
import com.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	UserService service;
	
	//List<User> userList = new ArrayList<User>();
	@RequestMapping(value = "/login")
	public String getLoginDetails(@RequestParam("username") String uname, @RequestParam("password") String pswd,Model model) {
		List<User> userList = service.getAllDetails(uname, pswd);
		if (userList != null) {
			model.addAttribute("list", userList);
			return "details";
		} else {
			model.addAttribute("mssg", "Invalid credential.. login again!!");
			return "login";
		}
		
	}
	
	@RequestMapping(value = "/register")
	public String registerUser(@ModelAttribute User user, Model model) {
		
		System.out.println("register contoller");
		System.out.println(user);
		int result = service.registerUser(user);
		
		if (result == 0) {
			return "login";
		} else {
			return "error";
		}
		
		/*
		 * if (user != null) { System.out.println(user); userList.add(user); return
		 * "login"; } else { System.out.println("user doesn't exist!!");
		 * model.addAttribute("message", "user doesn't exist!!"); return "login"; }
		 */
	}

}
