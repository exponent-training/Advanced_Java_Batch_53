package com.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Model.User;

@Controller
public class LoginController {

	private static final String un = "admin";

	private static final String ps = "admin123";

//	static List<User> ulist  = new ArrayList<User>();
	
	
	// webpagename -> modelandview

	// register page -> 12 fields -> beackend -> TASK

	// ModelandView. -> Model (Map) -> (K,v) , -> webpageName.

	// profile.jsp -> profile -> .jsp -> ViewResolver -> 1. adding web technology to
	// a pageName. , (Profile.jsp) , 2. location find -> Execute.

	@RequestMapping(value = "/log")
	public String getLogCall(@RequestParam("un") String username, @RequestParam("ps") String password, Model model) {

		System.out.println("Username :- " + username);
		System.out.println("Password :- " + password);

		if (un.equalsIgnoreCase(username) && ps.equals(password)) {
			return "profile";
		} else {
			model.addAttribute("msg", "Invalid Credentials");
			return "Login";
		}

	}

	@RequestMapping(value = "/reg")
	public String AddUsers(@ModelAttribute User user) {

		System.out.println(user);

		
		user = null;
		if (user != null) {
			
//			ulist.add(user);
			
			return "Login";
		} else {
			return "error";
		}

	}

}
