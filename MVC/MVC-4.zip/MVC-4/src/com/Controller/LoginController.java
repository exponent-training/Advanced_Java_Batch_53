package com.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ExceptionHandling.CustomeNullHandling;
import com.Model.User;

@Controller
public class LoginController {

	private static final String un = "admin";

	private static final String ps = "admin123";

//	static List<User> ulist  = new ArrayList<User>();

	// webpagename -> modelandview

	// register page -> 12 fields -> beackend -> TASK

	// ModelandView. -> Model (Map) -> (K,v) , -> webpageName.

	// profile.jsp -> profile -> .jsp -> ViewResolver -> 1. adding web technology to
	// a pageName. , (Profile.jsp) , 2. location find -> Execute.

//	100 -> methods -> 50 (nullpointer) -> 10 method (arithmatic) =>  
//	1. Centralized (Global) Exception Handling.
//	2. Controller Based exception handling.

	/*
	 * @ExceptionHandler(value = NullPointerException.class) public String
	 * handleNullpointer(NullPointerException ne) {
	 * System.out.println("First nullpointer handle");
	 * System.out.println(ne.getMessage()); return "error"; }
	 * 
	 * 
	 * @ExceptionHandler(value = NullPointerException.class) public String
	 * handleNull(NullPointerException ne) {
	 * System.out.println("Second nullpointer handle");
	 * System.out.println(ne.getMessage()); return "error"; }
	 */

//	@ExceptionHandler(value = ArithmeticException.class)
//	public String handlearithmatic(ArithmeticException ne) {
//		System.out.println(ne.getMessage());
//		return "error";
//	}
	
	@ExceptionHandler(value = CustomeNullHandling.class)
	public String handleNullpointer(CustomeNullHandling ne) {
//		System.out.println("First nullpointer handle");
		System.out.println("Controller Custome-null Handling");
		System.out.println(ne.getMessage());
		return "error";
	}

	@RequestMapping(value = "/log")
	public String getLogCall(@RequestParam("un") String username, @RequestParam("ps") String password, Model model) {

		System.out.println("Username :- " + username);
		System.out.println("Password :- " + password);

		try {
			String str = null;
			System.out.println(str.toLowerCase());
		} catch (Exception e) {
			throw new CustomeNullHandling("this is null value provide by CE");
		}

		if (un.equalsIgnoreCase(username) && ps.equals(password)) {
			return "profile";
		} else {
			model.addAttribute("msg", "Invalid Credentials");
			return "Login";
		}

	}

	@RequestMapping(value = "/reg")
	public String AddUsers(@ModelAttribute User user) {

		System.out.println(user);

		user = null;
		if (user != null) {

//			ulist.add(user);

			return "Login";
		} else {
			return "error";
		}

	}

}
