package com.ExceptionHandling;

public class CustomeNullHandling extends RuntimeException {

	public CustomeNullHandling(String msg) {
		super(msg);
	}
}
