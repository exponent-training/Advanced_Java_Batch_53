package com.DAOLayer;

import java.util.List;

import com.Model.FileDetails;
import com.Model.User;

public interface Userdao {

	public void addUserInDao(User user);

	public List<User>  loginUserInDao();

	public List<User> deleteUserInDAO(int id);

	public User getSingleUserByIDinDAO(int id);

	public List<User> updateUserInDao(User user);

	public void fileUploadInDao(FileDetails fd);
	
}
