package com.Enums;

public enum KycStatusEnum {

	NOT_VERIFIED, PARTIALLY_VERIFIED, FULLY_VERIFIED, REJECTED, EXPIRED, PENDING
}
