package com.ServiceIMPL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DTO.RegisterRequest;
import com.DTO.UserResponse;
import com.Entity.User;
import com.Exceptions.ResourceFoundExeption;
import com.Repository.UserRepo;
import com.Service.AuthenticationService;

@Service
public class AuthServiceIMPL implements AuthenticationService {

	@Autowired
	private UserRepo ur;

	@Override
	public UserResponse registerUser(RegisterRequest registerRequest) {

		User user = ur.findByEmail(registerRequest.getEmail()).orElseThrow(() -> new ResourceFoundExeption("User ALready exist"));
		
		
		System.out.println(user);
		
		return null;
	}
}
