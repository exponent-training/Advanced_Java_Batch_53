package com.Enums;

public enum RolesEnum {

	USER, ADMIN, SUPER_ADMIN

}
