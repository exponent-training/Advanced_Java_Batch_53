package com.Enums;

public enum UserStatusEnum {

	ACTIVE, INACTIVE
}
