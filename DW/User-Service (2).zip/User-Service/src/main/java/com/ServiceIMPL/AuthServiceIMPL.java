package com.ServiceIMPL;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DTO.RegisterRequest;
import com.DTO.UserResponse;
import com.Entity.User;
import com.Enums.KycStatusEnum;
import com.Enums.UserStatusEnum;
import com.Exceptions.UserAlreadyExist;
import com.Repository.UserRepo;
import com.Service.AuthenticationService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AuthServiceIMPL implements AuthenticationService {

	@Autowired
	private UserRepo ur;

	@Override
	public UserResponse registerUser(RegisterRequest registerRequest) {

		log.info("Register User Details" + registerRequest);

		if (ur.existsByEmail(registerRequest.getEmail())) {
			throw new UserAlreadyExist("User already exist with this email");
		}

		ModelMapper model1 = new ModelMapper();
		User user = model1.map(registerRequest, User.class);

		
//		ur.findByRol
		
		user.setKycStatus(KycStatusEnum.PENDING);
//		user.rol
		user.setStatus(UserStatusEnum.ACTIVE);
		User u = ur.save(user);

//		UserResponse ur = new UserResponse();
//		ur.setEmail(user.getEmail());
//		ur.setFirstName(user.getFirstName());
//		ur.setLastName(user.getLastName());
//		ur.setMiddleName(user.getMiddleName());
//		ur.setMobileNumber(user.getMobileNumber());
//		ur.setPassword(user.getPassword());
//		ur.setUsername(user.getUsername());

		ModelMapper model = new ModelMapper();
		UserResponse userResponse = model.map(u, UserResponse.class);

		return userResponse;
	}
}
