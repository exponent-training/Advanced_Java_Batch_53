package com.DTO;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Slf4j
//@Validated
public class RegisterRequest {

//	username , email , firstName , middleName , 
//	lastName , mobileNumber , password

//	Task -> Validate All fields.

	@Schema(example = "jcilacad")
//	@NotBlank(message = "Username cannot be empty")
	@JsonProperty(value = "un")
	private String username;

	@Schema(example = "johnchristopherilacad27@gmail.com")
//	@NotBlank(message = "Email cannot be empty")
//	@Email(message = "Invalid email format")
	@JsonProperty(value = "em")
	private String email;

	@Schema(example = "John")
//	@NotBlank(message = "First name cannot be empty")
	@JsonProperty(value = "firstName")
	private String firstName;

	private String middleName;

	@Schema(example = "Ilacad")
//	@NotBlank(message = "Last name cannot be empty")
	@JsonProperty(value = "lastName")
	private String lastName;

	@Schema(example = "+6391234567891")
//	@NotBlank(message = "Mobile number cannot be empty")
//	@Pattern(regexp = "(^$|\\+\\d{1,3}\\s?\\d{1,14})", message = "Invalid contact number. Please provide a valid mobile number.")
	@JsonProperty(value = "mobileNumber")
	private String mobileNumber;

	@Schema(example = "Password123!")
//	@NotBlank(message = "Password cannot be empty")
//	@Size(min = 8, message = "Password must be at least 8 characters long")
	@JsonProperty(value = "password")
//	@Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).*$", message = "Password must contain at least one lowercase letter, one uppercase letter, and one digit")
	private String password;

}
