package com.Exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.DTO.ErrorHandlingResponse;

@RestControllerAdvice
public class GlobalExceptionHandling {

	@ExceptionHandler(ResourceFoundExeption.class)
	public ResponseEntity<ErrorHandlingResponse> ResourceNotFoundHandle(ResourceFoundExeption re) {

		return new ResponseEntity(new ErrorHandlingResponse().builder().msg(re.getMessage()).build(),
				HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(UserAlreadyExist.class)
	public ResponseEntity<ErrorHandlingResponse> UserAlreayPresent(UserAlreadyExist re) {

		return new ResponseEntity(new ErrorHandlingResponse().builder().msg(re.getMessage()).build(),
				HttpStatus.NOT_FOUND);
	}

}
