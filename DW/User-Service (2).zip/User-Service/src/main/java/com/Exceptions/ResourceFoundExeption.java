package com.Exceptions;

public class ResourceFoundExeption extends RuntimeException {

	public ResourceFoundExeption(String msg) {
		super(msg);
	}

}
