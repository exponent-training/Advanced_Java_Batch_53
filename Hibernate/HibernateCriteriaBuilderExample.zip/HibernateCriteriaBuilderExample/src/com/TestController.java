package com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.util.HibernateUtil;

public class TestController {

	public static void main(String[] args) {

		SessionFactory sf = HibernateUtil.getSessionFactory();

//		getAllEmployeeDeatils(sf);

		//updateEmployeeDeatilsById(sf);
		
		//deleteEmployeeDeatilsById(sf);
		
		fetchLargestSalaryFromEmployeeInfo(sf);

	}

	private static void fetchLargestSalaryFromEmployeeInfo(SessionFactory sf) {
		Session session = sf.openSession();

		CriteriaBuilder builder = session.getCriteriaBuilder();

		CriteriaQuery<?> criteriaQuery = builder.createQuery(EmployeeInfo.class);
		
		Root<?> root = criteriaQuery.from(EmployeeInfo.class);
		
		//select max(salary) from EmployeeInfo;
		
		criteriaQuery.select(builder.max(root.get("salary")));

		Query<?> query = session.createQuery(criteriaQuery);
		
		Double maxsalary = (Double) query.getSingleResult();
		
		System.out.println("maxsalary= "+maxsalary);
		
	}

	private static void deleteEmployeeDeatilsById(SessionFactory sf) {
		Session session = sf.openSession();

		
		Transaction tx = session.beginTransaction();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();

		CriteriaDelete<EmployeeInfo> criteriaDelete = builder.createCriteriaDelete(EmployeeInfo.class);
		
		Root<EmployeeInfo> root = criteriaDelete.from(EmployeeInfo.class);
		
		// delete from EmployeeInfo where id = 5;
		
		criteriaDelete.where(builder.equal(root.get("id"),5));
		
		Query<?> query = session.createQuery(criteriaDelete);
		
		query.executeUpdate();
		
		tx.commit();
		
		System.out.println("successfully deleted!!");
		

		
	}

	public static void getAllEmployeeDeatils(SessionFactory sf) {

		Session session = sf.openSession();

		CriteriaBuilder builder = session.getCriteriaBuilder();

		CriteriaQuery<EmployeeInfo> criteriaQuery = builder.createQuery(EmployeeInfo.class);

		Root<EmployeeInfo> root = criteriaQuery.from(EmployeeInfo.class); // select * from EmployeeInfo;

		criteriaQuery.select(root);

		Query<EmployeeInfo> query = session.createQuery(criteriaQuery);

		List<EmployeeInfo> empList = query.getResultList();

		System.out.println("Employee's details:");
		for (EmployeeInfo employeeInfo : empList) {
			System.out.println(employeeInfo);
		}

	}

	public static void updateEmployeeDeatilsById(SessionFactory sf) {

		Session session = sf.openSession();

		Transaction tx = session.beginTransaction();

		CriteriaBuilder builder = session.getCriteriaBuilder();

		CriteriaUpdate<EmployeeInfo> criteriaQuery = builder.createCriteriaUpdate(EmployeeInfo.class);

		Root<EmployeeInfo> root = criteriaQuery.from(EmployeeInfo.class);

		criteriaQuery.set("salary", 90000);
		criteriaQuery.where(builder.equal(root.get("id"), 3)); // update empl set salary = 90000 where id =3

		Query<?> query = session.createQuery(criteriaQuery);

		query.executeUpdate();

		tx.commit();

		System.out.println("successfully updated!!");

	}
}
