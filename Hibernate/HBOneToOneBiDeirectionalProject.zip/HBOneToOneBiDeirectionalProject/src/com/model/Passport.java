package com.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Passport {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int passportid;
	
	private String passportNo;
	
	private String passportIssuename;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Person person;

	public int getPassportid() {
		return passportid;
	}

	public void setPassportid(int passportid) {
		this.passportid = passportid;
	}

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public String getPassportIssuename() {
		return passportIssuename;
	}

	public void setPassportIssuename(String passportIssuename) {
		this.passportIssuename = passportIssuename;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	@Override
	public String toString() {
		return "Passport [passportid=" + passportid + ", passportNo=" + passportNo + ", passportIssuename="
				+ passportIssuename + "]";
	}
	
	
	
}
