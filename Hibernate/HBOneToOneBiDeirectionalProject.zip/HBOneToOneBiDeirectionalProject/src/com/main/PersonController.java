package com.main;

import java.util.Scanner;

import com.service.PersonService;
import com.service.PersonServiceImpl;

public class PersonController {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		PersonService ps = new PersonServiceImpl();

		boolean flag = true;
		System.out.println("------------------PersonPassPortApplication------------");

		while (flag) {
			System.out.println("-------------------------------------------------");
			System.out.println("1. Save Person Data.");
			System.out.println("2. Save Passport Data.");
			System.out.println("3. Get Person Details Using Passport Id.");
			System.out.println("4. Get Passport Details Using Person Id.");
			System.out.println("5. getPersonAllDataWithPassportData.");
			System.out.println("6. getPassportAllDataWithPersonData");
			System.out.println("7. updatePersonAndPassportUsingPassportId.");
			System.out.println("8. updatePassprtOnlyUsingPassportId ");
			System.out.println("9. updatePersonOnlyUsingPassportId");
			System.out.println("10. updatePassprtOnlyUsingPersonId");
			System.out.println("11. updatePersonOnlyUsingPersonId");
			System.out.println("12. deletePassportAndPersonUsingPassportId");
			System.out.println("13. deletePersonOnlyUsingPassportId");
			System.out.println("14. deletePassportOnlyUsingPassportId");
			System.out.println("15. deletePersonOnlyUsingPersonId");
			System.out.println("16. deletePassportOnlyUsingPersonId");
			System.out.println("17. Exit");
			System.out.println("-------------------------------------------------");

			System.out.println();
			System.out.println("Enter your choice:");
			int ch = sc.nextInt();

			switch (ch) {
			case 1:
				ps.savePersonDataWithPassport();
				break;
			case 2:
				ps.savePassportwithPersonData();
				break;
			case 3:
				ps.getPersonDataByPassportId();
				break;
			case 4:
				ps.getPassportDataByPersonId();
				break;
			case 5:
				ps.getPersonAllDataWithPassportData();
				break;
			case 6:
				ps.getPassportAllDataWithPersonData();
				break;
			case 7:
				ps.updatePersonAndPassportUsingPassportId();
				break;
			case 8:
				ps.updatePassprtOnlyUsingPassportId();
				break;
			case 9:
				ps.updatePersonOnlyUsingPassportId();
				break;
			case 10:
				ps.updatePassprtOnlyUsingPersonId();
				break;
			case 11:
				ps.updatePersonOnlyUsingPersonId();
				;
				break;
			case 12:
				ps.deletePassportAndPersonUsingPassportId();
				break;
			case 13:
				ps.deletePersonOnlyUsingPassportId();
				break;
			case 14:
				ps.deletePassportOnlyUsingPassportId();
				;
				break;
			case 15:
				ps.deletePersonOnlyUsingPersonId();
				break;
			case 16:
				ps.deletePassportOnlyUsingPersonId();
				;
				break;
			case 17:
				flag = false;
				System.out.println("Thank you!!");
				break;

			default:
				break;
			}
		}

	}

}
