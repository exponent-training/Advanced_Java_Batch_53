package com.service;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.model.Passport;
import com.model.Person;
import com.util.HibernateUtil;

public class PersonServiceImpl implements PersonService{

	SessionFactory sf = HibernateUtil.getSessionFactory();
	
	Scanner sc = new Scanner(System.in);

	@Override
	public void savePersonDataWithPassport() {
		Session session = sf.openSession();
		
		System.out.println("Enter no. of person & passport you want to add:");
		int n = sc.nextInt();
		
		for(int i = 1;i<=n;i++) {
			Person p = new Person();
			System.out.println("enter name:");
			p.setName(sc.next());
			System.out.println("Enter address:");
			p.setAddress(sc.next());
			
			Passport passport = new Passport();
			System.out.println("Enter passportno:");
			passport.setPassportNo(sc.next());
			System.out.println("enter passportIssuename:");
			passport.setPassportIssuename(sc.next());
			
			passport.setPerson(p);
			p.setPassport(passport);
			
			session.save(passport);
			session.beginTransaction().commit();
			
		}
		System.out.println("Successfully inserted!!");
		
	}

	@Override
	public void savePassportwithPersonData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getPassportDataByPersonId() {
		
		Session session = sf.openSession();
		System.out.println("Enter person id:");
		int personid = sc.nextInt();
		Person person = session.get(Person.class, personid);
		if (person != null) {
			Passport passport = person.getPassport();
			System.out.println(passport);
		} else {
			System.out.println("person id doesn't exist!!");
		}
		
	}

	@Override
	public void getPersonDataByPassportId() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getPersonAllDataWithPassportData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getPassportAllDataWithPersonData() {
		Session session = sf.openSession();
		Query<Person> query = session.createQuery("FroM Person");
		List<Person> list = query.getResultList();
		System.out.println("Passport details:");
		for (Person person : list) {
			System.out.println(person.getPassport());
			System.out.println("---------------");
		}
	}

	@Override
	public void updatePersonAndPassportUsingPassportId() {
		Session session = sf.openSession();
		System.out.println("Enter passport id:");
		int passportid = sc.nextInt();
		Passport pass = session.get(Passport.class, passportid);
		if (pass != null) {
			System.out.println("enter new passportIssuename");
			String passportIssuenameNew = sc.next();
			pass.setPassportIssuename(passportIssuenameNew);
			Person pesron = pass.getPerson();
			System.out.println("enter updated name:");
			pesron.setName(sc.next());
			System.out.println("enter updated address:");
			pesron.setAddress(sc.next());
			session.update(pass);
			session.beginTransaction().commit();
			System.out.println("success!");
		} else {
			System.out.println("passport id doesn't exist!!");
		}
		
	}

	@Override
	public void updatePersonOnlyUsingPassportId() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updatePersonOnlyUsingPersonId() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updatePassprtOnlyUsingPersonId() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updatePassprtOnlyUsingPassportId() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletePersonOnlyUsingPassportId() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletePassportOnlyUsingPassportId() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletePassportAndPersonUsingPassportId() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletePersonOnlyUsingPersonId() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletePassportOnlyUsingPersonId() {
		// TODO Auto-generated method stub
		
	}
	
	
}
