package com.service;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.model.Passport;
import com.model.Person;
import com.util.HibernateUtil;

public class PersonServiceImpl implements PersonService {

	SessionFactory sf = HibernateUtil.getSessionFactory();

	Scanner sc = new Scanner(System.in);

	@Override
	public void savePersonDataWithPassport() {
		Session session = sf.openSession();

		System.out.println("Enter no. of person & passport you want to add:");
		int n = sc.nextInt();

		for (int i = 1; i <= n; i++) {
			Person p = new Person();
			System.out.println("enter name:");
			p.setName(sc.next());
			System.out.println("Enter address:");
			p.setAddress(sc.next());

			Passport passport = new Passport();
			System.out.println("Enter passportno:");
			passport.setPassportNo(sc.next());
			System.out.println("enter passportIssuename:");
			passport.setPassportIssuename(sc.next());

			passport.setPerson(p);
			p.setPassport(passport);

			session.save(passport);
			session.beginTransaction().commit();

		}
		System.out.println("Successfully inserted!!");

	}

	// HW
	@Override
	public void savePassportwithPersonData() {
		// TODO Auto-generated method stub

	}

	@Override
	public void getPassportDataByPersonId() {

		Session session = sf.openSession();
		System.out.println("Enter person id:");
		int personid = sc.nextInt();
		Person person = session.get(Person.class, personid);
		if (person != null) {
			Passport passport = person.getPassport();
			System.out.println(passport);
		} else {
			System.out.println("person id doesn't exist!!");
		}

	}

	// HW
	@Override
	public void getPersonDataByPassportId() {
		// TODO Auto-generated method stub

	}

	// HW
	@Override
	public void getPersonAllDataWithPassportData() {
		// TODO Auto-generated method stub

	}

	@Override
	public void getPassportAllDataWithPersonData() {
		Session session = sf.openSession();
		Query<Person> query = session.createQuery("FroM Person");
		List<Person> list = query.getResultList();
		System.out.println("Passport details:");
		for (Person person : list) {
			System.out.println(person.getPassport());
			System.out.println("---------------");
		}
	}

	@Override
	public void updatePersonAndPassportUsingPassportId() {
		Session session = sf.openSession();
		System.out.println("Enter passport id:");
		int passportid = sc.nextInt();
		Passport pass = session.get(Passport.class, passportid);
		if (pass != null) {
			System.out.println("enter new passportIssuename");
			String passportIssuenameNew = sc.next();
			pass.setPassportIssuename(passportIssuenameNew);
			Person pesron = pass.getPerson();
			System.out.println("enter updated name:");
			pesron.setName(sc.next());
			System.out.println("enter updated address:");
			pesron.setAddress(sc.next());
			session.update(pass);
			session.beginTransaction().commit();
			System.out.println("success!");
		} else {
			System.out.println("passport id doesn't exist!!");
		}

	}

	@Override
	public void updatePersonOnlyUsingPassportId() {
		Session session = sf.openSession();
		System.out.println("Enter passport id:");
		int passportid = sc.nextInt();

		Passport passport = session.get(Passport.class, passportid);

		if (passport != null) {
			Person person = passport.getPerson();
			System.out.println("Enter updated name:");
			person.setName(sc.next());
			System.out.println("Enter updated address:");
			person.setAddress(sc.next());
			session.update(person);
			session.beginTransaction().commit();
			System.out.println("person updated successfully!!");
		} else {
			System.out.println("passport doesn't exist!!");
		}

	}

	// HW
	@Override
	public void updatePersonOnlyUsingPersonId() {
		// TODO Auto-generated method stub

	}

	// HW
	@Override
	public void updatePassprtOnlyUsingPersonId() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updatePassprtOnlyUsingPassportId() {
		Session session = sf.openSession();
		System.out.println("Enter passport id:");
		int passportid = sc.nextInt();

		Passport passport = session.get(Passport.class, passportid);

		if (passport != null) {
			System.out.println("Enter passportIssuename:");
			passport.setPassportIssuename(sc.next());
			session.beginTransaction().commit();
			System.out.println("passport updated successfully!!");
		} else {
			System.out.println("passport doesn't exist!!");
		}

	}

	// HW
	@Override
	public void deletePersonOnlyUsingPassportId() {
		// TODO Auto-generated method stub

	}

	// HW
	@Override
	public void deletePassportOnlyUsingPassportId() {
		// TODO Auto-generated method stub

	}

	@Override
	public void deletePassportAndPersonUsingPassportId() {
		Session session = sf.openSession();
		System.out.println("Enter passport id:");
		int passportid = sc.nextInt();

		Passport passport = session.get(Passport.class, passportid);

		if (passport != null) {
			session.delete(passport);
			session.beginTransaction().commit();
			System.out.println("Deleted successfully!!");
		} else {
			System.out.println("passport doesn't exist!!");
		}

	}

	@Override
	public void deletePersonOnlyUsingPersonId() {
		Session session = sf.openSession();
		System.out.println("Enter person id:");
		int personId = sc.nextInt();
		Person person = session.get(Person.class, personId);
		if (person != null) {
			Passport passport2 = person.getPassport();
			person.setPassport(null);
			passport2.setPerson(null);
			session.update(passport2);
			session.delete(person);
			session.beginTransaction().commit();
			System.out.println("Person Deleted successfully!!");

		} else {
			System.out.println("person doesn't exist!!");
		}

	}

	@Override
	public void deletePassportOnlyUsingPersonId() {
		Session session = sf.openSession();
		System.out.println("Enter person id:");
		int personId = sc.nextInt();
		Person person = session.get(Person.class, personId);
		if (person != null) {
			Passport passportObj = person.getPassport();
			passportObj.setPerson(null);
			person.setPassport(null);
			session.update(person);
			session.delete(passportObj);
			session.beginTransaction().commit();
			System.out.println("passport Deleted successfully!!");

		} else {
			System.out.println("person doesn't exist!!");
		}

	}

}
