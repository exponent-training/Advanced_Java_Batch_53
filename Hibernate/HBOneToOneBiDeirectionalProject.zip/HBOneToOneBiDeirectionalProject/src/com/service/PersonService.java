package com.service;

public interface PersonService {
	
	
	public void savePersonDataWithPassport();
	
	public void savePassportwithPersonData();
	
	public void getPassportDataByPersonId();
	
	public void getPersonDataByPassportId();
	
	public void getPersonAllDataWithPassportData(); // HQL

	public void getPassportAllDataWithPersonData();
	
	public void updatePersonAndPassportUsingPassportId();
	
	public void updatePersonOnlyUsingPassportId();
	
	public void updatePersonOnlyUsingPersonId();
	
	public void updatePassprtOnlyUsingPersonId();
	
	public void updatePassprtOnlyUsingPassportId();
	
	public void deletePersonOnlyUsingPassportId();
	
	public void deletePassportOnlyUsingPassportId();
	
	public void deletePassportAndPersonUsingPassportId();

	public void deletePersonOnlyUsingPersonId();

	public void deletePassportOnlyUsingPersonId();
}
