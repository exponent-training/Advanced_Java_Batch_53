package com;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;



@NamedQueries({
	@NamedQuery(name = "fetchAllEmployeeDetails", query = "from EmployeeInfo"),
	@NamedQuery(name = "fetchEnameAndsalary" , query = "select ename, salary from EmployeeInfo")
})

@NamedNativeQueries({
	@NamedNativeQuery(name = "fetchAllEmployeeDetailsByNativeQuery", query = "select * from employeeInfo", resultClass = EmployeeInfo.class),
	@NamedNativeQuery(name = "deleteEmployeebyId", query = "delete from EmployeeInfo where id=:idIn"),
	@NamedNativeQuery(name = "deleteEmployeeInfobyId", query = "delete from EmployeeInfo where id=?")
})

@Entity
public class EmployeeInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String ename;
	
	private double salary;
	
	private String address;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "EmployeeInfo [id=" + id + ", ename=" + ename + ", salary=" + salary + ", address=" + address + "]";
	}
	
	
}
