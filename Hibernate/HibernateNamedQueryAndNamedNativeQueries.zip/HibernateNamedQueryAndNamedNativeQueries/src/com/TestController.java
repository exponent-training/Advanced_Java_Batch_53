package com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.util.HibernateUtil;

public class TestController {

	public static void main(String[] args) {

		SessionFactory sf = HibernateUtil.getSessionFactory();

		/*
		 * Session session = sf.openSession();
		 * 
		 * EmployeeInfo e1 = new EmployeeInfo();
		 * 
		 * e1.setEname("ameya"); e1.setSalary(50000.00); e1.setAddress("pune");
		 * 
		 * EmployeeInfo e2 = new EmployeeInfo();
		 * 
		 * e2.setEname("pratiksha"); e2.setSalary(70000.00); e2.setAddress("pune");
		 * 
		 * EmployeeInfo e3 = new EmployeeInfo();
		 * 
		 * e3.setEname("swati"); e3.setSalary(6700.00); e3.setAddress("mumbai");
		 * 
		 * EmployeeInfo e4 = new EmployeeInfo();
		 * 
		 * e4.setEname("rashmi"); e4.setSalary(27000.00); e4.setAddress("mumbai");
		 * 
		 * EmployeeInfo e5 = new EmployeeInfo();
		 * 
		 * e5.setEname("atharva"); e5.setSalary(69000.00); e5.setAddress("nashik");
		 * 
		 * List<EmployeeInfo> elist = new ArrayList<EmployeeInfo>();
		 * Collections.addAll(elist, e1,e2,e3,e4,e5);
		 * 
		 * for (EmployeeInfo employeeInfo : elist) { session.save(employeeInfo); }
		 */

		/*
		 * fetchAllDetail(sf); fetchAllDetailByNativeQuery(sf);
		 */

		// fetchEnameAndsalaryFromEmployeeInfo(sf);

		// deleteEmployeebyId(sf);

		deleteEmployeeInfobyId(sf);

		System.out.println("success!!");

	}

	private static void deleteEmployeeInfobyId(SessionFactory sf) {
		Session session = sf.openSession();

		Transaction tx = session.beginTransaction();
		Query<?> query = session.getNamedNativeQuery("deleteEmployeeInfobyId");
		query.setParameter(1, 4);
		query.executeUpdate();
		tx.commit();

	}

	private static void deleteEmployeebyId(SessionFactory sf) {
		Session session = sf.openSession();

		Transaction tx = session.beginTransaction();
		Query<?> query = session.getNamedNativeQuery("deleteEmployeebyId");
		query.setParameter("idIn", 1);
		query.executeUpdate();
		tx.commit();

	}

	private static void fetchEnameAndsalaryFromEmployeeInfo(SessionFactory sf) {
		Session session = sf.openSession();

		Query<Object[]> query = session.createNamedQuery("fetchEnameAndsalary");

		List<Object[]> list = query.getResultList();

		for (Object[] employees : list) {

			System.out.println(Arrays.toString(employees));

		}
	}

	private static void fetchAllDetailByNativeQuery(SessionFactory sf) {
		Session session = sf.openSession();

		System.out.println("----By namedNaiveQuery----------");

		Query<EmployeeInfo> query = session.getNamedNativeQuery("fetchAllEmployeeDetailsByNativeQuery");

		List<EmployeeInfo> eList = query.getResultList();

		for (EmployeeInfo employeeInfo : eList) {
			System.out.println(employeeInfo);
		}
	}

	private static void fetchAllDetail(SessionFactory sf) {
		Session session = sf.openSession();
		System.out.println("----By namedQuery----------");
		Query<EmployeeInfo> query = session.getNamedQuery("fetchAllEmployeeDetails");

		List<EmployeeInfo> list = query.getResultList();

		for (EmployeeInfo employeeInfo : list) {
			System.out.println(employeeInfo);
		}

	}
}
